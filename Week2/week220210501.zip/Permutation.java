/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;

public class Permutation {


    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        String strings = StdIn.readString(args[1]);
    }
}
